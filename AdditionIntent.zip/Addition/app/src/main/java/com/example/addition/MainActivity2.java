package com.example.addition;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    TextView disp;
    int num;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        num=Integer.valueOf(getIntent().getStringExtra("result"));
        disp = findViewById(R.id.disp1);
        disp.setText(String.valueOf(num));


    }
}
