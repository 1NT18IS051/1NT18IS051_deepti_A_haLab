package com.example.addition;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText n1;
    EditText n2;
    Button btn;
    TextView s;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        n1=findViewById(R.id.n1);
        n2=findViewById(R.id.n2);
        btn=findViewById(R.id.btn);
        s=findViewById(R.id.s);

        btn.setOnClickListener(new View.OnClickListener() {
                                   @Override
                                   public void onClick(View view) {
                                      int sum=Integer.parseInt(n1.getText().toString())+Integer.parseInt(n2.getText().toString());
                                      //if(sum>10)
                                          //Log.i("result","Greater than 10");
                                      //s.setText("Result is "+sum);
                                   }
                               }

        );


        }
        protected void onStart(){
        super.onStart();
        Log.d("ActivityTutorial","onStart");

    }
}
